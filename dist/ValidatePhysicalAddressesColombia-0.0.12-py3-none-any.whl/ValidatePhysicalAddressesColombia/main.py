


def ejec():
    import functions
    functions.run()


if __name__ == '__main__':
    ejec()

